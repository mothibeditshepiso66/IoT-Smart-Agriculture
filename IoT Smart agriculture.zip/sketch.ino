#include <Arduino.h>
#include <WiFi.h>
#include <PubSubClient.h>
#include <Wire.h>
#include <Adafruit_BMP085.h>
#include <DHT.h>
#include <ArduinoJson.h>
#include <LiquidCrystal_I2C.h>

// ---- Pin definitions ----
#define DHT_PIN    15
#define DHT_TYPE   DHT22
#define SOIL_PIN   34
#define PUMP_PIN   26

// ---- LCD ----
LiquidCrystal_I2C lcd(0x27, 16, 2);

// ---- WiFi & MQTT Config ----
// Use a public broker for testing, or your own Mosquitto/EMQX
const char* WIFI_SSID     = "Wokwi-GUEST";
const char* WIFI_PASSWORD = "";
const char* MQTT_SERVER   = "broker.emqx.io";  // Free public broker
const int   MQTT_PORT     = 1883;
const char* MQTT_TOPIC    = "esp32/sensors/data";
const char* MQTT_CLIENT_ID = "ESP32-SensorNode";

// ---- Replay data ----
const float pressureArr[] = {
  1006.28,1006.32,1006.24,1004.12,1004.85,1006.27,1005.51,1003.83,1007.01,1005.01,
  1004.60,1004.41,1005.82,1005.35,1035.21,1041.90,1017.29,1040.97,1028.09,1003.70,
  1005.61,1005.77,1005.90,1006.03,1009.04,1005.32,1003.37,1003.23,1002.48,1003.53,
  1003.28,1003.43,1006.11,1006.15,1006.14,1006.14,1006.15,1003.13,1002.97,1005.60,
  1007.73,1002.99,1002.97,1008.06,1008.11,1002.88,1002.85,1002.90,1008.18,1008.17
};
const int soilArr[] = {
  27,28,28,37,38,38,38,38,38,38, 38,38,39,39,39,39,40,40,40,40,
  40,40,40,40,41,41,41,41,41,41, 41,41,41,41,41,41,41,42,42,43,
  43,43,43,44,44,44,44,45,45,45
};
const float bmpTempArr[] = {
  104.29,104.36,104.58,130.41,127.15,132.22,133.90,116.02,133.14,131.38,
  128.41,125.73,124.48,118.78,121.69,130.55,132.62,132.39,132.66,105.60,
  114.35,114.55,111.52,112.28,130.86,129.85,128.77,102.40,128.30,103.35,
  103.60,103.82,110.44,108.52,108.55,107.44,110.01,101.88,101.57,125.44,
  123.35,100.04,99.18,121.96,118.56,97.90,95.49,94.82,116.13,116.01
};
const float humidityArr[] = {
  49.9,46.9,46.9,13.9,11.5,12.1,13.4,13.5,14.1,15.2,
  15.5,19.5,11.2,11.3,13.9,15.1,16.0,13.2,14.9,18.7,
  30.1,31.4,31.9,33.8,16.0,16.4,17.3,19.4,19.9,30.2,
  30.2,30.7,34.4,34.5,35.7,41.5,44.7,27.5,29.8,25.0,
  25.7,30.1,31.2,26.7,29.3,32.8,34.4,36.0,30.1,32.8
};
const float dhtTempArr[] = {
  93.20,97.88,97.88,135.86,142.70,145.58,137.84,138.92,137.12,129.74,
  129.56,118.94,147.74,145.76,140.36,135.68,135.50,142.16,139.10,122.00,
  118.04,114.80,114.62,112.82,135.86,136.04,133.70,118.40,128.84,103.10,
  102.38,100.40,111.56,111.20,109.58,101.12,101.66,106.52,101.66,125.78,
  124.34,100.04,98.42,123.98,119.12,96.62,93.20,91.94,118.40,115.88
};
const int SAMPLE_COUNT = 50;
const int HISTORY_MAX  = 50;

// ---- Objects ----
Adafruit_BMP085 bmp;
DHT dht(DHT_PIN, DHT_TYPE);
WiFiClient espClient;
PubSubClient mqttClient(espClient);

struct Reading {
  float pressure, bmpTemp, humidity, dhtTemp;
  int   soil;
  bool  pump;
};
Reading history[HISTORY_MAX];
int  historyIdx = 0, replayIdx = 0, historyLen = 0;
bool pumpState = false;
unsigned long lastPublish = 0;
const unsigned long PUBLISH_INTERVAL = 3000;  // Publish every 3 seconds

// ---- Forward declarations ----
void takeReading();
void updateLCD(float p, float bt, float hm, float dt, int sm, bool pump);
void connectWiFi();
void connectMQTT();
void publishReading(Reading &r);
void mqttCallback(char* topic, byte* payload, unsigned int length);

// ---- Setup ----
void setup() {
  Serial.begin(115200);
  delay(1500);
  Serial.println();
  Serial.println("=== BOOT START ===");

  Wire.begin(21, 22);

  // LCD init
  lcd.init();
  lcd.backlight();
  lcd.setCursor(0, 0);
  lcd.print("Booting...");
  Serial.println("LCD initialized");

  // BMP180
  if (!bmp.begin()) Serial.println("BMP180 NOT FOUND");
  else              Serial.println("BMP180 OK");

  // DHT22
  dht.begin();
  Serial.println("DHT22 initialized");

  // Pump
  pinMode(PUMP_PIN, OUTPUT);
  digitalWrite(PUMP_PIN, LOW);
  Serial.println("Pump pin ready");

  // WiFi
  connectWiFi();

  // MQTT
  mqttClient.setServer(MQTT_SERVER, MQTT_PORT);
  mqttClient.setCallback(mqttCallback);
  connectMQTT();

  Serial.println("=== BOOT DONE ===");
}

// ---- Loop ----
void loop() {
  if (!mqttClient.connected()) {
    connectMQTT();
  }
  mqttClient.loop();

  if (millis() - lastPublish > PUBLISH_INTERVAL) {
    lastPublish = millis();
    takeReading();
  }
}

// ---- WiFi Connection ----
void connectWiFi() {
  Serial.print("Connecting WiFi");
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  int tries = 0;
  while (WiFi.status() != WL_CONNECTED && tries < 40) {
    delay(200); Serial.print("."); tries++;
  }
  Serial.println();
  if (WiFi.status() == WL_CONNECTED) {
    Serial.print("WiFi OK. IP: ");
    Serial.println(WiFi.localIP());
    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print("WiFi OK");
    lcd.setCursor(0, 1);
    lcd.print(WiFi.localIP());
    delay(1500);
  } else {
    Serial.println("WiFi FAILED");
  }
}

// ---- MQTT Connection ----
void connectMQTT() {
  while (!mqttClient.connected()) {
    Serial.print("Attempting MQTT connection...");
    if (mqttClient.connect(MQTT_CLIENT_ID)) {
      Serial.println("connected");
      // Subscribe to control topic if you want remote pump control
      // mqttClient.subscribe("esp32/pump/control");
    } else {
      Serial.print("failed, rc=");
      Serial.print(mqttClient.state());
      Serial.println(" retry in 5s");
      delay(5000);
    }
  }
}

// ---- MQTT Callback (for future remote control) ----
void mqttCallback(char* topic, byte* payload, unsigned int length) {
  Serial.print("Message arrived on topic: ");
  Serial.println(topic);
  // Handle pump control commands here if needed
}

// ---- Publish Reading as JSON ----
void publishReading(Reading &r) {
  StaticJsonDocument<256> doc;
  doc["pressure"] = r.pressure;
  doc["bmpTemp"]  = r.bmpTemp;
  doc["humidity"] = r.humidity;
  doc["dhtTemp"]  = r.dhtTemp;
  doc["soil"]     = r.soil;
  doc["pump"]     = r.pump;

  char buffer[256];
  serializeJson(doc, buffer);
  mqttClient.publish(MQTT_TOPIC, buffer);
  Serial.print("Published: ");
  Serial.println(buffer);
}

// ---- Reading logic ----
void takeReading() {
  float p  = pressureArr[replayIdx];
  int   sm = soilArr[replayIdx];
  float bt = bmpTempArr[replayIdx];
  float hm = humidityArr[replayIdx];
  float dt = dhtTempArr[replayIdx];

  // Glitch filter
  if (p < 900 || p > 1100)
    p = historyIdx > 0 ? history[(historyIdx-1+HISTORY_MAX)%HISTORY_MAX].pressure : 1005.0;
  if (bt > 200)
    bt = historyIdx > 0 ? history[(historyIdx-1+HISTORY_MAX)%HISTORY_MAX].bmpTemp : 100.0;

  // Pump control with hysteresis
  if (sm < 45 && !pumpState) pumpState = true;
  if (sm > 60 &&  pumpState) pumpState = false;
  digitalWrite(PUMP_PIN, pumpState ? HIGH : LOW);

  Reading current = { p, bt, hm, dt, sm, pumpState };
  history[historyIdx] = current;
  historyIdx = (historyIdx + 1) % HISTORY_MAX;
  if (historyLen < HISTORY_MAX) historyLen++;
  replayIdx = (replayIdx + 1) % SAMPLE_COUNT;

  Serial.printf("P=%.2f BMP=%.2f H=%.2f DHT=%.2f Soil=%d Pump=%s\n",
                p, bt, hm, dt, sm, pumpState ? "ON" : "OFF");

  updateLCD(p, bt, hm, dt, sm, pumpState);
  publishReading(current);
}

// ---- LCD display ----
void updateLCD(float p, float bt, float hm, float dt, int sm, bool pump) {
  static int page = 0;
  lcd.clear();
  if (page == 0) {
    lcd.setCursor(0, 0);
    lcd.print("T:"); lcd.print(bt, 1); lcd.print("F H:"); lcd.print(hm, 0); lcd.print("%");
    lcd.setCursor(0, 1);
    lcd.print("DHT:"); lcd.print(dt, 1); lcd.print("F      ");
  } else if (page == 1) {
    lcd.setCursor(0, 0);
    lcd.print("P:"); lcd.print(p, 1); lcd.print("hPa");
    lcd.setCursor(0, 1);
    lcd.print("Soil:"); lcd.print(sm); lcd.print("% Pump:"); lcd.print(pump ? "ON" : "OF");
  } else {
    lcd.setCursor(0, 0);
    lcd.print("ESP32 Dashboard");
    lcd.setCursor(0, 1);
    lcd.print("Pump: "); lcd.print(pump ? "ON " : "OFF");
  }
  page = (page + 1) % 3;
}
